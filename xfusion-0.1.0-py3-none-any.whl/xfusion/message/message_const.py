Telegram_Bot_API_URL_Prefix = "https://api.telegram.org"
Proxy_URL_Prefix = "https://us.xsolutiontech.com"
